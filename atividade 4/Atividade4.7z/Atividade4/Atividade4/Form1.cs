﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics.Eventing.Reader;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade4
{
    public partial class Form1 : Form   
    {
        double ladoA, ladoB, ladoC;

        public Form1()
        {
            InitializeComponent();
        }

        private void txtbA_Validated(object sender, EventArgs e)
        {
            if(!double.TryParse(txtbA.Text, out ladoA))
            {
                MessageBox.Show("Entrada inválida");
                txtbA.Focus();
            }
        }

        private void btnVerificar_MouseClick(object sender, MouseEventArgs e)
        {
            if ((ladoA > (Math.Abs(ladoB - ladoC))) && (ladoA < (ladoB + ladoC)) && 
                (ladoB > (Math.Abs(ladoA - ladoC))) && (ladoB < (ladoA + ladoC)) &&
                (ladoC > (Math.Abs(ladoA - ladoB))) && (ladoC < (ladoA + ladoB)))
            {
                if(ladoA == ladoB && ladoA == ladoC && ladoB == ladoC)
                {
                    MessageBox.Show("Triângulo equilátero");
                }
                else if(ladoA != ladoB && ladoA != ladoC && ladoB != ladoC)
                {
                    MessageBox.Show("Triângulo escaleno");
                }
                else
                {
                    MessageBox.Show("Triângulo isosceles");
                }
                  
            }
            else
            {
                MessageBox.Show("Não é um triângulo");
            }
            
        }

        private void btnLimpar_MouseClick(object sender, MouseEventArgs e)
        {
            txtbA.Clear();
            txtbB.Clear();
            txtbC.Clear();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtbB_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbB.Text, out ladoB))
            {
                MessageBox.Show("Entrada inválida");
                txtbB.Focus();
            }
        }

        private void txtbC_Validated(object sender, EventArgs e)
        {
            if (!double.TryParse(txtbC.Text, out ladoC))
            {
                MessageBox.Show("Entrada inválida");
                txtbC.Focus();
            }
        }
    }

}
