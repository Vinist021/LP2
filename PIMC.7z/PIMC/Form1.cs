﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;

        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void mskbxPeso_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            IMC = peso / (altura * altura);
            IMC = Math.Round(IMC, 1);

            txtIMC.Text = IMC.ToString();
            if (IMC < 18.5)
            {
                MessageBox.Show("Magreza");
            }
            else if (IMC <= 24.9)
            {
                MessageBox.Show("Normal");
            }
            else if (IMC <= 29.9)
            {
                MessageBox.Show("Sobrepeso");
            }
            else if (IMC <= 39.9)
            {
                MessageBox.Show("Obesidade");
            }
            else
            {
                MessageBox.Show("Obesidade grave");
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
           

        }

        private void mskbxPeso_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskbxPeso.Text, out peso)) || (peso  <= 0))
            {
                MessageBox.Show("peso inválido");
                mskbxPeso.Focus();
            }
        }

        private void mskbxAltura_Validated(object sender, EventArgs e)
        {
            if ((!double.TryParse(mskbxAltura.Text, out altura)) || (altura <= 0))
            {
                MessageBox.Show("altura inválida");
                mskbxPeso.Focus();
            }
        }

        private void btnSair_Click(object sender, EventArgs e)
        {

        }
    }
}
